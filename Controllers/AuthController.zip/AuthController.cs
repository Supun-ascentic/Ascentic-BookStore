﻿namespace Ascentic_BookStore.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;

        public AuthController(UserManager<IdentityUser> usermanager,SignInManager<IdentityUser> signinmanager )
        {
            this.userManager = usermanager;
            this.signInManager = signinmanager;
        }

       
        [Authorize]
        public string Secret()
        {
            const string message = "Secret Message";
            return message;
        }

        [HttpPost]
        public async Task<string> Login(string username,string password)
        {
            var user = await this.userManager.FindByNameAsync(username);

            if (user != null)
            {
                var signInResult = await this.signInManager.PasswordSignInAsync(user, password, false, false);

                if (signInResult.Succeeded)
                {
                    const string sucessMessage = "Log in Success";
                    return sucessMessage;
                }
            }

            const string message = "Log in Failed";
            return message;
        }

        [HttpPost]
        public async Task<string> Registrer(string username, string email, string password)
        {

            var user = new IdentityUser
            {
                UserName = username,
                Email = email,
            };

            var result = await this.userManager.CreateAsync(user);

            if (result.Succeeded)
            {

            }

            const string message = "Registered";
            return message;
        }

     
        public async Task<string> LogoutAsync()
        {
            await this.signInManager.SignOutAsync();
            const string message = "LoggedOut";
            return message;
        }
    }
}